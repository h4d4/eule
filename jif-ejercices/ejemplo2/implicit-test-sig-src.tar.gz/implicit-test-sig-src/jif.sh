#! /bin/bash

jif -classpath 'jif-classes' $@
