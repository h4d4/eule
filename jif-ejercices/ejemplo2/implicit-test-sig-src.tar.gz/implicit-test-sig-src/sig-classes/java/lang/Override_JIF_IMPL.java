package java.lang;

public abstract class Override_JIF_IMPL {
    
    public static boolean jif$Instanceof(final Object o) {
        return o instanceof Override;
    }
    
    public static Override jif$cast$java_lang_Override(final Object o) {
        if (o == null) return null;
        if (jif$Instanceof(o)) return (Override) o;
        throw new ClassCastException();
    }
    
    public Override_JIF_IMPL() { super(); }
    
    public static final String jlc$CompilerVersion$jl = "2.6.1";
    public static final long jlc$SourceLastModified$jl = 0L;
    public static final String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAI1WXWxURRSevW23P1S2rYCVn7LAii3gNjwYgyUqNBS2Lra2" +
       "oLEE1tl755aB2Tu3c2fLAtagiYH4wAMWBBN5wkQNQmJCjDEkfVIIvmiMxgd/" +
       "3jRRHnjRFxXPzOzd3d6F6iZ3du6Z8zfnfOece/k2agoESvqcHZ1kXKblUZ8E" +
       "6VEsAuIMMhwEe4CQs89u7J99+0DHxw0oMYES1BuXWFJ7kHuSlOQEai+QQp6I" +
       "YJvjEGcCdXqEOONEUMzoMWDk3gTqCuikh2VRkGCMBJxNK8auoOgToW2GxCxq" +
       "t7kXSFG0JReBRB3ZQ3ga9xclZf1ZGsiBLIq7lDAnmEKvolgWNbkMTwLjsmx4" +
       "i36tsX9I0YG9jYKbwsU2CUUaD1PPkWh1VKJy49SzwACizQUiD/KKqUYPAwF1" +
       "GZcY9ib7x6Wg3iSwNvEiWJFo+X2VAlOLj+3DeJLkJOqO8o2aI+Bq1WFRIhIt" +
       "jbJpTSWBlkdyVpOt289tPX3c2+VZ2meH2Ez53wRCPRGhMeISQTybGMH2Ddlz" +
       "eNn1UxZCwLw0wmx4PnnlzjObeuZuGJ4V9+AZyR8itszZl/KLv1o52LelQbnR" +
       "4vOAKijMu7nO6mj5ZKDkAxaXVTSqw3R4ODf2+UsnPiS/Wagtg+I2Z8UCoKrT" +
       "5gWfMiJ2Eo8ILImTQa3Ecwb1eQY1wz5LPWKoI64bEJlBjUyT4ly/Q4hcUKFC" +
       "1Ah76rk83PtYHtT7kn8XfjF4/lEPgp8iqH+Aw2DZiWTFC98vKbkHjsRicKWV" +
       "0fJigMVdnDlE5OzZ4vYdd67kblkVgJUtSrRCwSytYJYemSZCUIfkhjNDuczu" +
       "0SyKxbTuJZpHhwouehgKCGqkvW98//DLp9Y2QI78I43gpWJNRRFTrbMM7DDA" +
       "IGcnTv76x9VzM7yKHYlSdZCul1SQXBu9p+A2caDkq+o3JPG13PWZlKXi2wqV" +
       "LjHkAsqmJ2pjHjQHwjJXsbGyaJHLRQEzdRTWZps8KPiRKkUnYJFaEiYXKlgR" +
       "B3WHGPp07sK1dzZusWqbSaKm64wTaaDZWY31HkEI0H84P/rW2dsn9+lAA8e6" +
       "exlIqVVhBAM2uHjjxtT3P/146RurmhyJ4n4xz6hdAh3rq1YAxgxKCeAfpPZ6" +
       "Be5Ql+I8IyrHfyUe2Xzt99MdJlEMKObaAm36bwVV+sPb0YlbB/7s0Wpitmqj" +
       "1ZtX2UwAHqxq3iYEPqr8KL329aoLX+B3ocqhsgJ6jJR8VRf6ZkiHvldnZJ1e" +
       "H42cbVDL8pI+W1Km65cVeu1RyxpNt9R2rUQtOA/gw7aMCAm06n4tUbfzS6/P" +
       "XnRG3ttsGlfX/DazwysWPvr27y/T53++eY9KbJXcf4yRacJqbFpgcnXE5G49" +
       "L6p4/2D35Zs719tnLNRQKae6sTNfaKDWOOBaEJianrqGojTrqHVrNxaDE+pB" +
       "qxSIkPnFTFM6U9+UnkxOFXFAp4pckt5AT/CkgV0yzzkj2Eseom4q9IO7vftc" +
       "6mGWVFk/jgv5Gd2LzM40eb1P8v1Dfcnjxs9kL0/SioZk2Lf6Bmb6wqa4cHrj" +
       "xrNSBDOxchtT753wVVDTGrUnWvVTCwBtu1qekGjx/DsG9UNxVNACzJzp8lAk" +
       "p2bfvJs+PWvVfDmsqxvetTLm60FbbTMNCKysWciKlhj65erMZ+/PnLTKHm+W" +
       "qLmcGH2jx03Sw8HTHSY7JKjTjv8TZLVsvU+A1evTWsXIAsF8Xi3DakJBMG0c" +
       "yJTKR07lIxemPExVV/0UK0nUWTfRVIPprvsQNZ9L9pWLiZaHLu79Ts+NyidN" +
       "HL4r3CJjNeVSWzpxXxCXaofjZhyY4LwIBV1xSkLzhD/t7QvmfAJo6lzt9/km" +
       "Iv8CDDyqFSoLAAA=");
}
